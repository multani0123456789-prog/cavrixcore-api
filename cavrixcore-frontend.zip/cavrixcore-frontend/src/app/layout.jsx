import React from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import Hero from "../sections/Hero";
import Services from "../sections/Services";

export default function Layout() {
  return (
    <div className="min-h-screen bg-bg text-white antialiased">
      <div className="bg-gradient-to-br from-[rgba(0,246,255,0.03)] via-[rgba(139,92,246,0.03)] to-[rgba(0,246,255,0.01)] min-h-screen backdrop-blur-sm">
        <Header />
        <main className="max-w-6xl mx-auto px-6">
          <Hero />
          <Services />
        </main>
        <Footer />
      </div>
    </div>
  );
}
