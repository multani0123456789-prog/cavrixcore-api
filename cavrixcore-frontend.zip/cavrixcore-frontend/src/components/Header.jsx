import React from "react";

export default function Header() {
  return (
    <header className="border-b border-[rgba(255,255,255,0.1)] py-6 text-center font-display text-xl">
      <span className="bg-gradient-to-r from-neon to-accent bg-clip-text text-transparent">
        CavrixCore
      </span>
    </header>
  );
}
