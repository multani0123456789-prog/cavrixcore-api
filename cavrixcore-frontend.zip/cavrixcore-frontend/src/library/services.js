// static + future API-ready
const services = [
  {
    plan: "Starter",
    price: 1999,
    desc: "Single-page website for creators & early startups.",
    features: ["1 page", "Contact form", "3 revisions"],
  },
  {
    plan: "Growth",
    price: 4999,
    desc: "Business website with CMS, SEO basics and analytics.",
    features: ["Up to 5 pages", "SEO basics", "Analytics"],
  },
  {
    plan: "Ultimate",
    price: 9999,
    desc: "Full e-commerce + AI assistant integration and priority support.",
    features: ["E-commerce", "AI assistant", "Priority support"],
  },
];

export default services;
