import React, { useEffect, useRef } from "react";
import servicesData from "../lib/services";
import { gsap } from "gsap";

function ServiceCard({ plan, price, desc, features }) {
  return (
    <div className="card-glass p-6 rounded-2xl border border-[rgba(255,255,255,0.03)] min-h-[220px] flex flex-col justify-between">
      <div>
        <div className="text-sm text-gray-300">Plan</div>
        <div className="mt-2 text-2xl font-display">{plan}</div>
        <div className="mt-2 text-gray-200 font-semibold">₹{price}</div>
        <p className="mt-3 text-gray-400 text-sm">{desc}</p>
      </div>
      <div className="mt-4 flex items-center justify-between">
        <a href="#contact" className="px-4 py-2 rounded-lg bg-gradient-to-r from-neon to-accent text-black font-medium">
          Buy
        </a>
        <div className="text-xs text-gray-400">Fast delivery • 3 revisions</div>
      </div>
    </div>
  );
}

export default function Services() {
  const wrap = useRef(null);

  useEffect(() => {
    const q = gsap.utils.selector(wrap);
    const cards = q(".service-card");
    gsap.from(cards, {
      opacity: 0,
      y: 24,
      stagger: 0.12,
      duration: 0.8,
      ease: "power3.out",
      scrollTrigger: {
        trigger: wrap.current,
        start: "top 85%",
      },
    });
  }, []);

  return (
    <section id="services" ref={wrap} className="py-20">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center">
          <h3 className="text-3xl font-display">Our Packages</h3>
          <p className="mt-2 text-gray-400">Productized packages to launch fast — choose what fits your stage.</p>
        </div>

        <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6">
          {servicesData.map((s) => (
            <div key={s.plan} className="service-card">
              <ServiceCard {...s} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
