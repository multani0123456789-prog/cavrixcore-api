import React, { useEffect, useRef } from "react";
import { gsap } from "gsap";

export default function Hero() {
  const root = useRef(null);
  const tlRef = useRef(null);

  useEffect(() => {
    const el = root.current;
    if (!el) return;

    // basic cinematic timeline
    const heading = el.querySelector(".hero-heading");
    const sub = el.querySelector(".hero-sub");
    const cta = el.querySelector(".hero-cta");
    const heroBg = el.querySelector(".hero-bg");

    tlRef.current = gsap.timeline({ defaults: { ease: "power3.out" } });
    tlRef.current
      .fromTo(
        heroBg,
        { scale: 1.05, opacity: 0.7 },
        { scale: 1, opacity: 1, duration: 1.4 }
      )
      .fromTo(
        heading,
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.9 },
        "-=0.9"
      )
      .fromTo(sub, { y: 18, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7 }, "-=0.6")
      .fromTo(cta, { y: 12, opacity: 0, scale: 0.98 }, { y: 0, opacity: 1, scale: 1, duration: 0.6 }, "-=0.4");

    // subtle floating parallax on mousemove
    const handleMove = (e) => {
      const rect = el.getBoundingClientRect();
      const mx = (e.clientX - rect.left) / rect.width - 0.5;
      const my = (e.clientY - rect.top) / rect.height - 0.5;
      gsap.to(heroBg, { x: mx * 12, y: my * 8, duration: 0.8, ease: "power1.out" });
    };

    window.addEventListener("mousemove", handleMove);

    return () => {
      window.removeEventListener("mousemove", handleMove);
      tlRef.current && tlRef.current.kill();
    };
  }, []);

  return (
    <section ref={root} className="relative overflow-hidden py-24">
      <div className="hero-bg absolute inset-0 pointer-events-none opacity-90" />
      <div className="max-w-5xl mx-auto px-6 text-center relative z-10">
        <h2 className="hero-heading text-4xl md:text-6xl font-display leading-tight">
          Designing the Future Web — <span className="text-gradient">Precision. Performance. Perfection.</span>
        </h2>
        <p className="hero-sub mt-4 text-gray-300 max-w-2xl mx-auto">
          Your digital identity, re-engineered by CavrixCore.
        </p>

        <div className="mt-8 flex items-center justify-center gap-4">
          <a
            href="#contact"
            className="hero-cta inline-flex items-center gap-3 px-6 py-3 rounded-2xl font-semibold bg-gradient-to-r from-neon to-accent text-black shadow-lg"
          >
            Get a Free Quote
          </a>
          <a href="#services" className="inline-flex items-center gap-2 text-sm text-gray-300 hover:underline">
            See Packages
          </a>
        </div>
      </div>

      {/* decorative lights - CSS handles colors */}
      <div aria-hidden className="absolute -left-40 -top-40 w-96 h-96 rounded-full opacity-20 blur-3xl bg-neon/30"></div>
      <div aria-hidden className="absolute -right-40 -bottom-40 w-96 h-96 rounded-full opacity-20 blur-3xl bg-accent/30"></div>
    </section>
  );
}
